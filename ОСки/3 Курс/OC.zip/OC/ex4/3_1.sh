#! /bin/bash

bash ./$1
echo "////"

