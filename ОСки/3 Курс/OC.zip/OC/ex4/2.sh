#! /bin/bash

export a=2
export b=5

echo "Math is fun!"
echo "$a + $b = $(($a+$b))"
echo "$a - $b = $(($a-$b))"
echo "$a * $b = $(($a*$b))"
echo "$a / $b = $(($a/$b))"
echo "$a^$b = $(($a**$b))"

