#! /bin/bash

read -n 1 -s -p $'PRESS ANY KEY\n'
