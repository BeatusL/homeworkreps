while true;
do
	sleep 10
	echo "background process still running"
done
