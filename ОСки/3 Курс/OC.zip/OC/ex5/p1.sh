echo "Press any key"
read anykey
sleep 10
echo "Foreground process is still running"
