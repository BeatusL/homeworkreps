echo "FG program active"
echo "Press any key"
read a
sleep 5
echo "nazar nazar $a"
sleep 10
echo "FG program shutting down"
